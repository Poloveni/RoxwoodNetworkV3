import "dotenv/config";
import { z } from "zod";

/**
 * Schema de validation des variables d'environnement attendues par le bot.
 * `DEV_GUILD_ID` est optionnel : s'il est absent, les commandes slash sont enregistrees
 * globalement (propagation jusqu'a ~1h) plutot que sur une seule guilde de dev (instantane).
 */
const envSchema = z.object({
  DISCORD_TOKEN: z.string().min(1, "DISCORD_TOKEN manquant"),
  CLIENT_ID: z.string().min(1, "CLIENT_ID manquant"),
  DATABASE_URL: z.string().min(1, "DATABASE_URL manquant"),
  DEV_GUILD_ID: z.string().optional(),

  /**
   * Port d'ecoute de l'API de lecture (src/http/server.ts). Jamais publie sur l'hote :
   * seul le reverse proxy Caddy, sur le meme reseau Docker, s'y connecte.
   */
  API_PORT: z.coerce.number().int().positive().default(8080),

  /**
   * Origines autorisees a appeler l'API depuis un navigateur, separees par des virgules.
   * Defaut : le site GitHub Pages de l'espace membre. Toute autre origine est refusee au
   * niveau CORS — c'est une liste blanche, pas un joker.
   */
  API_ALLOWED_ORIGINS: z
    .string()
    .default("https://poloveni.github.io")
    .transform((value) =>
      value
        .split(",")
        .map((origin) => origin.trim())
        .filter((origin) => origin.length > 0),
    ),

  /**
   * Guilde Discord dont l'API expose les donnees, et dont l'appartenance conditionne
   * l'acces. Absent = seule /api/health repond ; les routes de donnees refusent plutot
   * que de servir un serveur non identifie.
   */
  API_GUILD_ID: z.string().optional(),

  /**
   * Roles ouvrant les sections reservees (candidatures, commandes, journaux en jeu,
   * coffre, flux sortants), separes par des virgules. Vide = tout membre du serveur y
   * accede — pratique pour demarrer, mais le bot journalise un avertissement, parce que
   * le coffre et les factures sont des donnees d'entreprise.
   */
  API_STAFF_ROLE_IDS: z
    .string()
    .default("")
    .transform((value) =>
      value
        .split(",")
        .map((id) => id.trim())
        .filter((id) => id.length > 0),
    ),
});

const parsed = envSchema.safeParse(process.env);

// Echec rapide et explicite plutot que de laisser le bot demarrer avec une config incomplete.
if (!parsed.success) {
  console.error("Variables d'environnement invalides :", parsed.error.flatten().fieldErrors);
  process.exit(1);
}

/** Variables d'environnement validees et typees, a importer partout ailleurs dans le code. */
export const env = parsed.data;
