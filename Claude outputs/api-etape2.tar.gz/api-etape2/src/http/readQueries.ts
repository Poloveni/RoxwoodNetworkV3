import { prisma } from "../db/prisma.js";
import {
  computeDiscountAmount,
  computeGrandTotal,
  computeTotal,
  computeTotalWeightGrams,
} from "../services/orderService.js";

/**
 * Requetes de lecture pour l'API de l'espace membre.
 *
 * Les services existants sont tailles pour une interaction Discord : ils lisent une
 * candidature, une commande, un coffre a la fois. Une interface web a besoin de listes et
 * d'agregats — c'est ce que ce fichier ajoute, sans toucher au reste du bot.
 *
 * Trois regles tenues partout ici :
 *
 *  - Toute requete est filtree par `guildId`. L'isolation entre serveurs Discord est deja
 *    la regle du bot, elle ne s'arrete pas a l'API.
 *  - Les colonnes `Bytes` (photos d'articles, banniere, pieces jointes) ne sont JAMAIS
 *    selectionnees : les charger enverrait des megaoctets de binaire dans du JSON. On
 *    expose leur presence et leur nom, pas leur contenu.
 *  - Les secrets (`WebhookSubscription.secret`) ne sortent pas, et les URL de destination
 *    sont reduites a leur hote : un secret suffit a signer de faux evenements, et l'URL
 *    d'un Google Sheet partage est elle-meme une donnee sensible.
 */

/** Bornes de pagination : garde-fou contre une requete qui ramenerait toute la base. */
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 200;

export function clampLimit(raw: string | null): number {
  const value = Number(raw);
  if (!Number.isFinite(value) || value <= 0) return DEFAULT_LIMIT;
  return Math.min(Math.floor(value), MAX_LIMIT);
}

/* ---------------------------------------------------------------- Recrutement */

export async function listRecruitment(guildId: string, limit: number) {
  const [config, applications] = await Promise.all([
    prisma.guildConfig.findUnique({
      where: { guildId },
      select: {
        recruitmentOpen: true,
        recruitmentAcceptedCategoryId: true,
        recruitmentAcceptedRoleId: true,
      },
    }),
    prisma.recruitmentApplication.findMany({
      where: { ticket: { guildId } },
      orderBy: { updatedAt: "desc" },
      take: limit,
      select: {
        id: true,
        status: true,
        recruiterId: true,
        submittedAt: true,
        createdAt: true,
        updatedAt: true,
        ticket: { select: { channelId: true, openerId: true, status: true } },
        answers: { select: { question: true, answer: true } },
        // Le contenu binaire reste en base ; seul le nom du fichier remonte.
        attachments: { select: { filename: true } },
      },
    }),
  ]);

  return {
    open: config?.recruitmentOpen ?? false,
    acceptedCategoryConfigured: Boolean(config?.recruitmentAcceptedCategoryId),
    acceptedRoleConfigured: Boolean(config?.recruitmentAcceptedRoleId),
    applications: applications.map((application) => ({
      id: application.id,
      status: application.status,
      recruiterId: application.recruiterId,
      candidateId: application.ticket.openerId,
      channelId: application.ticket.channelId,
      ticketStatus: application.ticket.status,
      submittedAt: application.submittedAt,
      updatedAt: application.updatedAt,
      answers: application.answers,
      attachments: application.attachments.map((a) => a.filename),
    })),
  };
}

/* ------------------------------------------------------------------ Commandes */

export async function listOrders(guildId: string, limit: number) {
  const orders = await prisma.serviceOrder.findMany({
    where: { ticket: { guildId } },
    orderBy: { updatedAt: "desc" },
    take: limit,
    select: {
      id: true,
      status: true,
      paymentStatus: true,
      invoiceNumber: true,
      confirmed: true,
      deliveryFee: true,
      discountPercent: true,
      createdAt: true,
      updatedAt: true,
      ticket: { select: { channelId: true, openerId: true } },
      items: {
        select: {
          name: true,
          unitPrice: true,
          quantity: true,
          weightGrams: true,
          answers: { select: { question: true, answer: true } },
        },
      },
    },
  });

  const config = await prisma.guildConfig.findUnique({
    where: { guildId },
    select: { truckCapacityGrams: true },
  });
  const truckCapacityGrams = config?.truckCapacityGrams ?? null;

  return orders.map((order) => {
    // Les totaux sont calcules par les fonctions du bot, importees telles quelles : le site
    // doit afficher exactement le meme montant que la facture Discord, pas une reimplementation
    // qui divergerait a la premiere evolution des regles.
    const totalWeightGrams = computeTotalWeightGrams(order);

    return {
      id: order.id,
      status: order.status,
      paymentStatus: order.paymentStatus,
      invoiceNumber: order.invoiceNumber,
      confirmed: order.confirmed,
      channelId: order.ticket.channelId,
      clientId: order.ticket.openerId,
      items: order.items,
      subtotal: computeTotal(order),
      deliveryFee: order.deliveryFee,
      discountPercent: order.discountPercent,
      discountAmount: computeDiscountAmount(order),
      total: computeGrandTotal(order),
      totalWeightGrams,
      // Meme regle que la facture : omis si l'information n'existe pas, jamais force a zero.
      trucksRequired:
        totalWeightGrams !== null && truckCapacityGrams
          ? Math.ceil(totalWeightGrams / truckCapacityGrams)
          : null,
      updatedAt: order.updatedAt,
    };
  });
}

/* ------------------------------------------------------- Catalogue & boutique */

export async function getCatalog(guildId: string) {
  const [items, config] = await Promise.all([
    prisma.catalogItem.findMany({
      where: { guildId },
      orderBy: [{ active: "desc" }, { name: "asc" }],
      select: {
        id: true,
        name: true,
        description: true,
        price: true,
        weightGrams: true,
        active: true,
        // Presence de la photo, jamais ses octets.
        imageFilename: true,
        fields: {
          orderBy: { position: "asc" },
          select: { label: true, style: true, required: true },
        },
      },
    }),
    prisma.guildConfig.findUnique({
      where: { guildId },
      select: {
        shopRib: true,
        shopPhone: true,
        shopThankYouMessage: true,
        shopBannerFilename: true,
        truckCapacityGrams: true,
      },
    }),
  ]);

  return {
    items: items.map(({ imageFilename, ...item }) => ({
      ...item,
      hasImage: Boolean(imageFilename),
    })),
    shop: {
      // Le RIB est une coordonnee de paiement in-game, deja imprimee sur chaque facture
      // remise au client : la masquer ici n'apporterait rien.
      rib: config?.shopRib ?? null,
      phone: config?.shopPhone ?? null,
      thankYouMessage: config?.shopThankYouMessage ?? null,
      hasBanner: Boolean(config?.shopBannerFilename),
      truckCapacityGrams: config?.truckCapacityGrams ?? null,
    },
  };
}

/* ------------------------------------------------------------------- Absences */

export async function listAbsences(guildId: string, limit: number) {
  return prisma.absenceRequest.findMany({
    where: { guildId },
    orderBy: { createdAt: "desc" },
    take: limit,
    select: {
      id: true,
      requesterId: true,
      startDate: true,
      endDate: true,
      reason: true,
      status: true,
      resolverId: true,
      resolvedAt: true,
      createdAt: true,
    },
  });
}

/* -------------------------------------------------------- Activite en jeu */

export async function getMonitoring(guildId: string) {
  const since = new Date(Date.now() - 24 * 3600 * 1000);

  const [config, last24h, total, channels] = await Promise.all([
    prisma.guildConfig.findUnique({
      where: { guildId },
      select: { monitoringJobId: true, onDutyRoleId: true },
    }),
    prisma.monitoringEvent.groupBy({
      by: ["type"],
      where: { guildId, createdAt: { gte: since } },
      _count: { _all: true },
    }),
    prisma.monitoringEvent.count({ where: { guildId } }),
    prisma.monitoringChannelConfig.findMany({
      where: { guildId },
      select: { type: true },
    }),
  ]);

  return {
    jobConfigured: Boolean(config?.monitoringJobId),
    onDutyRoleConfigured: Boolean(config?.onDutyRoleId),
    configuredTypes: channels.map((c) => c.type),
    last24hByType: Object.fromEntries(last24h.map((row) => [row.type, row._count._all])),
    last24hTotal: last24h.reduce((sum, row) => sum + row._count._all, 0),
    storedTotal: total,
  };
}

/* --------------------------------------------------------- Coffre d'entreprise */

export async function getStorage(guildId: string, limit: number) {
  const safes = await prisma.monitoringSafe.findMany({
    where: { guildId },
    select: { id: true, positionKey: true },
  });

  if (safes.length === 0) return { safes: [], stock: [], movements: [] };

  const safeIds = safes.map((safe) => safe.id);
  const labelOf = new Map(safes.map((safe) => [safe.id, safe.positionKey]));

  const [sums, movements] = await Promise.all([
    // Stock courant = somme du ledger. Le bot n'entretient pas de compteur mutable :
    // l'historique fait foi et reste auditable.
    prisma.monitoringSafeMovement.groupBy({
      by: ["safeId", "itemId"],
      where: { safeId: { in: safeIds } },
      _sum: { quantity: true },
    }),
    prisma.monitoringSafeMovement.findMany({
      where: { safeId: { in: safeIds } },
      orderBy: { createdAt: "desc" },
      take: limit,
      select: {
        id: true,
        safeId: true,
        itemId: true,
        quantity: true,
        playerName: true,
        playerDiscordId: true,
        createdAt: true,
      },
    }),
  ]);

  return {
    safes: safes.map((safe) => ({ id: safe.id, label: safe.positionKey })),
    stock: sums
      .map((row) => ({
        safeId: row.safeId,
        safeLabel: labelOf.get(row.safeId) ?? row.safeId,
        itemId: row.itemId,
        quantity: row._sum.quantity ?? 0,
      }))
      .sort((a, b) => a.safeLabel.localeCompare(b.safeLabel) || a.itemId.localeCompare(b.itemId)),
    movements: movements.map((movement) => ({
      ...movement,
      safeLabel: labelOf.get(movement.safeId) ?? movement.safeId,
      // Le signe porte deja l'information ; on l'explicite pour l'affichage.
      direction: movement.quantity >= 0 ? "IN" : "OUT",
    })),
  };
}

/* ------------------------------------------------------------ Flux sortants */

/** Reduit une URL a son hote : de quoi reconnaitre un destinataire sans divulguer le lien. */
function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return "(url invalide)";
  }
}

export async function listWebhooks(guildId: string) {
  const subscriptions = await prisma.webhookSubscription.findMany({
    where: { guildId },
    orderBy: [{ eventType: "asc" }, { createdAt: "asc" }],
    select: {
      id: true,
      eventType: true,
      label: true,
      url: true,
      enabled: true,
      createdAt: true,
      // `secret` est volontairement absent de ce select.
      sheetSync: { select: { enabled: true, lastRowCount: true } },
      deliveryAttempts: {
        orderBy: { nextAttemptAt: "asc" },
        select: { attempts: true, nextAttemptAt: true, lastError: true },
      },
    },
  });

  return subscriptions.map((subscription) => ({
    id: subscription.id,
    eventType: subscription.eventType,
    label: subscription.label,
    targetHost: hostOf(subscription.url),
    enabled: subscription.enabled,
    createdAt: subscription.createdAt,
    sheetSync: subscription.sheetSync
      ? { enabled: subscription.sheetSync.enabled, rowsSent: subscription.sheetSync.lastRowCount }
      : null,
    // Livraisons en attente de nouvelle tentative : le meilleur indicateur de sante d'un flux.
    pendingRetries: subscription.deliveryAttempts.length,
    nextRetryAt: subscription.deliveryAttempts[0]?.nextAttemptAt ?? null,
    lastError: subscription.deliveryAttempts[0]?.lastError ?? null,
  }));
}

/* ------------------------------------------------------------- Vue d'ensemble */

/**
 * Compteurs de la vue d'ensemble. Chaque bloc n'est calcule que si le visiteur a le droit
 * de le voir : un compteur est deja une information, meme sans le detail derriere.
 */
export async function getOverview(
  guildId: string,
  scope: { recruitment: boolean; orders: boolean; monitoring: boolean },
) {
  const since = new Date(Date.now() - 24 * 3600 * 1000);

  const [pendingApplications, unpaidOrders, pendingAbsences, logs24h] = await Promise.all([
    scope.recruitment
      ? prisma.recruitmentApplication.count({
          where: { ticket: { guildId }, status: { in: ["PENDING", "INTERVIEW"] } },
        })
      : Promise.resolve(null),
    scope.orders
      ? prisma.serviceOrder.count({
          where: { ticket: { guildId }, confirmed: true, paymentStatus: "UNPAID" },
        })
      : Promise.resolve(null),
    prisma.absenceRequest.count({ where: { guildId, status: "PENDING" } }),
    scope.monitoring
      ? prisma.monitoringEvent.count({ where: { guildId, createdAt: { gte: since } } })
      : Promise.resolve(null),
  ]);

  return { pendingApplications, unpaidOrders, pendingAbsences, logs24h };
}
