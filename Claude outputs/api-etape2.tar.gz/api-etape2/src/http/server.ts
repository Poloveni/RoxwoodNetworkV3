import { createServer, type IncomingMessage, type ServerResponse } from "node:http";

import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";
import { canRead, grantedSections, type Section } from "./access.js";
import { AuthError, readBearer, resolveViewer, type Viewer } from "./discordAuth.js";
import {
  clampLimit,
  getCatalog,
  getMonitoring,
  getOverview,
  getStorage,
  listAbsences,
  listOrders,
  listRecruitment,
  listWebhooks,
} from "./readQueries.js";

/**
 * API de lecture de l'espace membre, dans le meme process que le bot.
 *
 * Pourquoi ici plutot qu'un service separe : les donnees vivent deja dans la base a
 * laquelle ce process est connecte, et les fonctions de calcul des totaux sont deja
 * importables — le site affiche donc exactement les memes montants que la facture Discord.
 * Un second conteneur imposerait une seconde connexion Prisma et un second deploiement.
 *
 * Pourquoi `node:http` plutot qu'Express ou Fastify : la surface est minuscule (routes GET,
 * pas de corps de requete a parser, pas de sessions) et le projet tient volontairement sa
 * liste de dependances courte.
 *
 * Ce serveur n'est jamais publie sur l'hote : il n'ecoute que sur le reseau Docker, et
 * c'est Caddy qui l'expose en HTTPS.
 */

type Handler = (ctx: { viewer: Viewer; url: URL; guildId: string }) => Promise<unknown>;

type Route = {
  path: string;
  /** Section dont depend l'acces ; `null` pour une route accessible a tout membre connecte. */
  section: Section | null;
  handle: Handler;
};

const startedAt = Date.now();

const routes: Route[] = [
  {
    path: "/api/me",
    section: null,
    handle: async ({ viewer }) => ({
      id: viewer.id,
      name: viewer.name,
      avatarUrl: viewer.avatarUrl,
      isStaff: viewer.isStaff,
      sections: grantedSections(viewer),
    }),
  },
  {
    path: "/api/overview",
    section: "overview",
    handle: ({ viewer, guildId }) =>
      getOverview(guildId, {
        recruitment: canRead(viewer, "recruitment"),
        orders: canRead(viewer, "orders"),
        monitoring: canRead(viewer, "monitoring"),
      }),
  },
  {
    path: "/api/recruitment",
    section: "recruitment",
    handle: ({ url, guildId }) => listRecruitment(guildId, clampLimit(url.searchParams.get("limit"))),
  },
  {
    path: "/api/orders",
    section: "orders",
    handle: ({ url, guildId }) => listOrders(guildId, clampLimit(url.searchParams.get("limit"))),
  },
  {
    path: "/api/catalog",
    section: "catalog",
    handle: ({ guildId }) => getCatalog(guildId),
  },
  {
    path: "/api/absences",
    section: "absences",
    handle: ({ url, guildId }) => listAbsences(guildId, clampLimit(url.searchParams.get("limit"))),
  },
  {
    path: "/api/monitoring",
    section: "monitoring",
    handle: ({ guildId }) => getMonitoring(guildId),
  },
  {
    path: "/api/storage",
    section: "storage",
    handle: ({ url, guildId }) => getStorage(guildId, clampLimit(url.searchParams.get("limit"))),
  },
  {
    path: "/api/webhooks",
    section: "webhooks",
    handle: ({ guildId }) => listWebhooks(guildId),
  },
];

/**
 * Origines autorisees a appeler cette API depuis un navigateur.
 *
 * On repond `Access-Control-Allow-Origin` avec l'origine exacte de la requete quand elle
 * figure dans la liste, jamais `*` : les routes portent un en-tete `Authorization`, et un
 * joker interdirait justement son envoi.
 */
function resolveAllowedOrigin(origin: string | undefined): string | undefined {
  if (!origin) return undefined;
  return env.API_ALLOWED_ORIGINS.includes(origin) ? origin : undefined;
}

function applyCors(req: IncomingMessage, res: ServerResponse): void {
  const allowed = resolveAllowedOrigin(req.headers.origin);
  if (!allowed) return;

  res.setHeader("Access-Control-Allow-Origin", allowed);
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
  res.setHeader("Access-Control-Max-Age", "86400");
  // Une reponse mise en cache pour une origine ne doit jamais etre resservie a une autre.
  res.setHeader("Vary", "Origin");
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(payload),
    // Donnees d'entreprise : aucun cache intermediaire ne doit les conserver.
    "cache-control": "no-store",
  });
  res.end(payload);
}

async function handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  applyCors(req, res);

  // Requete preliminaire CORS, envoyee par le navigateur avant tout appel portant
  // un en-tete Authorization.
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);

  // Sonde de bout en bout : ne touche pas la base, n'expose rien, donc pas d'authentification.
  if (url.pathname === "/api/health") {
    sendJson(res, 200, {
      ok: true,
      service: "roxwood-network-bot",
      uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000),
      guildConfigured: Boolean(env.API_GUILD_ID),
    });
    return;
  }

  const route = routes.find((r) => r.path === url.pathname);
  if (!route) {
    sendJson(res, 404, { error: "not_found" });
    return;
  }
  if (req.method !== "GET") {
    sendJson(res, 405, { error: "method_not_allowed" });
    return;
  }

  try {
    const viewer = await resolveViewer(readBearer(req.headers.authorization));

    if (route.section && !canRead(viewer, route.section)) {
      // 403 et rien d'autre : ni le nombre d'elements, ni un apercu partiel.
      sendJson(res, 403, { error: "forbidden", section: route.section });
      return;
    }

    // `resolveViewer` a deja refuse la requete si la guilde n'est pas configuree.
    const guildId = env.API_GUILD_ID as string;
    sendJson(res, 200, await route.handle({ viewer, url, guildId }));
  } catch (error) {
    if (error instanceof AuthError) {
      sendJson(res, error.status, { error: error.code });
      return;
    }
    // Le detail part dans les logs du conteneur, jamais dans la reponse : un message
    // d'erreur brut renseigne un attaquant sur la structure interne.
    logger.error(`Erreur non geree dans l'API HTTP sur ${url.pathname}`, error);
    sendJson(res, 500, { error: "internal_error" });
  }
}

/** Demarre le serveur. Un echec ici ne doit jamais empecher le bot Discord de tourner. */
export function startHttpServer(): void {
  const server = createServer((req, res) => {
    void handleRequest(req, res);
  });

  server.on("error", (error) => {
    logger.error("Erreur du serveur HTTP", error);
  });

  server.listen(env.API_PORT, "0.0.0.0", () => {
    logger.info(`API de lecture a l'ecoute sur le port ${env.API_PORT}`);
    if (!env.API_GUILD_ID) {
      logger.warn("API_GUILD_ID absent : seule /api/health repondra, les routes de donnees refuseront.");
    }
  });
}
