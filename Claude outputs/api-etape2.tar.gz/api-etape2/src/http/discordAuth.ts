import { createHash } from "node:crypto";

import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";

/**
 * Authentification des appels a l'API de lecture.
 *
 * Le navigateur se connecte a Discord (flux implicite, cote site) et envoie ici le jeton
 * d'acces obtenu, en `Authorization: Bearer <jeton>`. Ce module en deduit qui appelle et
 * ce qu'il a le droit de voir.
 *
 * Deux appels a Discord, avec deux identites differentes, et c'est volontaire :
 *
 *  1. `GET /users/@me` avec le jeton du visiteur — prouve que le jeton est valide et a qui
 *     il appartient. Seul le porteur legitime peut fournir un jeton que Discord accepte.
 *
 *  2. `GET /guilds/{guilde}/members/{utilisateur}` avec le jeton du BOT — donne
 *     l'appartenance et les roles. On ne demande pas ces informations au navigateur : le
 *     scope `guilds` du visiteur listerait ses serveurs, mais ses roles exigeraient un
 *     scope supplementaire, et surtout la reponse transiterait par un client qu'on ne
 *     controle pas. Le bot est deja sur la guilde et fait autorite — autant lui demander.
 *
 * Un 404 sur le second appel signifie simplement "pas membre" : c'est la reponse normale
 * de Discord, pas une erreur.
 */

const DISCORD_API = "https://discord.com/api/v10";

/** Duree de vie du cache d'identite. Court : une exclusion du serveur doit prendre effet vite. */
const CACHE_TTL_MS = 60_000;

export type Viewer = {
  id: string;
  /** Nom affichable : pseudo de serveur s'il existe, sinon nom global, sinon identifiant. */
  name: string;
  avatarUrl: string | null;
  /** Ids des roles Discord detenus sur la guilde. */
  roles: string[];
  /** Vrai si le visiteur detient au moins un role declare dans API_STAFF_ROLE_IDS. */
  isStaff: boolean;
};

export class AuthError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
  ) {
    super(code);
  }
}

type CacheEntry = { viewer: Viewer; expiresAt: number };

/**
 * Cache en memoire, indexe par empreinte du jeton plutot que par le jeton lui-meme : le
 * jeton d'un visiteur n'a aucune raison de sejourner en clair dans une structure a longue
 * duree de vie. L'empreinte suffit a reconnaitre un appelant deja vu.
 */
const cache = new Map<string, CacheEntry>();

function fingerprint(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

function pruneCache(now: number): void {
  for (const [key, entry] of cache) {
    if (entry.expiresAt <= now) cache.delete(key);
  }
}

/** Extrait le jeton d'un en-tete `Authorization: Bearer <jeton>`. */
export function readBearer(header: string | undefined): string {
  const value = (header ?? "").trim();
  if (!value.toLowerCase().startsWith("bearer ")) {
    throw new AuthError(401, "missing_token");
  }
  const token = value.slice(7).trim();
  if (!token) throw new AuthError(401, "missing_token");
  return token;
}

function avatarUrl(userId: string, avatar: string | null): string | null {
  if (!avatar) return null;
  const ext = avatar.startsWith("a_") ? "gif" : "png";
  return `https://cdn.discordapp.com/avatars/${userId}/${avatar}.${ext}?size=128`;
}

type DiscordUser = { id: string; username: string; global_name?: string | null; avatar: string | null };
type DiscordMember = { nick?: string | null; roles?: string[] };

async function discordFetch(path: string, authorization: string): Promise<Response> {
  return fetch(`${DISCORD_API}${path}`, {
    headers: { Authorization: authorization },
    // Sans garde-fou, une lenteur de Discord immobiliserait une requete du site.
    signal: AbortSignal.timeout(8_000),
  });
}

/**
 * Resout le visiteur derriere un jeton, ou leve une `AuthError`.
 * Les erreurs sont volontairement grossieres cote client (`invalid_token`, `not_member`) :
 * le detail part dans les logs, pas dans la reponse.
 */
export async function resolveViewer(token: string): Promise<Viewer> {
  const now = Date.now();
  pruneCache(now);

  const key = fingerprint(token);
  const cached = cache.get(key);
  if (cached && cached.expiresAt > now) return cached.viewer;

  if (!env.API_GUILD_ID) {
    // Sans guilde de reference, aucune verification d'appartenance n'est possible : on
    // refuse plutot que de laisser passer tout porteur d'un jeton Discord valide.
    throw new AuthError(503, "guild_not_configured");
  }

  let userResponse: Response;
  try {
    userResponse = await discordFetch("/users/@me", `Bearer ${token}`);
  } catch (error) {
    logger.error("Discord injoignable lors de la verification du jeton", error);
    throw new AuthError(503, "discord_unreachable");
  }

  if (userResponse.status === 401) throw new AuthError(401, "invalid_token");
  if (userResponse.status === 429) throw new AuthError(429, "rate_limited");
  if (!userResponse.ok) {
    logger.error(`Reponse inattendue de Discord sur /users/@me : ${userResponse.status}`);
    throw new AuthError(502, "discord_error");
  }

  const user = (await userResponse.json()) as DiscordUser;

  let memberResponse: Response;
  try {
    memberResponse = await discordFetch(
      `/guilds/${env.API_GUILD_ID}/members/${user.id}`,
      `Bot ${env.DISCORD_TOKEN}`,
    );
  } catch (error) {
    logger.error("Discord injoignable lors de la lecture du membre", error);
    throw new AuthError(503, "discord_unreachable");
  }

  // Reponse normale pour quelqu'un qui n'a pas rejoint le serveur.
  if (memberResponse.status === 404) throw new AuthError(403, "not_member");
  if (memberResponse.status === 429) throw new AuthError(429, "rate_limited");
  if (!memberResponse.ok) {
    logger.error(`Reponse inattendue de Discord sur /guilds/:id/members/:id : ${memberResponse.status}`);
    throw new AuthError(502, "discord_error");
  }

  const member = (await memberResponse.json()) as DiscordMember;
  const roles = member.roles ?? [];

  const viewer: Viewer = {
    id: user.id,
    name: member.nick || user.global_name || user.username,
    avatarUrl: avatarUrl(user.id, user.avatar),
    roles,
    // Liste vide = personne n'est distingue : tout membre voit tout (voir access.ts).
    isStaff:
      env.API_STAFF_ROLE_IDS.length === 0 || roles.some((r) => env.API_STAFF_ROLE_IDS.includes(r)),
  };

  cache.set(key, { viewer, expiresAt: now + CACHE_TTL_MS });
  return viewer;
}
