import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";
import type { Viewer } from "./discordAuth.js";

/**
 * Qui voit quoi.
 *
 * La regle est appliquee ICI, cote serveur, et pas a l'affichage : une section interdite
 * ne doit pas seulement etre masquee dans la page, ses donnees ne doivent pas quitter le
 * VPS. C'est toute la difference entre un tableau de bord d'entreprise et une page publique
 * avec un habillage de connexion.
 *
 * Le decoupage suit celui du bot : le README exclut deliberement le coffre des commandes
 * Discord parce que c'est une donnee d'entreprise sensible. Candidatures, commandes,
 * journaux en jeu, coffre et abonnements webhook suivent la meme logique. Le catalogue et
 * les absences, eux, concernent tout le monde.
 */

export const SECTIONS = [
  "overview",
  "recruitment",
  "orders",
  "catalog",
  "absences",
  "monitoring",
  "storage",
  "webhooks",
] as const;

export type Section = (typeof SECTIONS)[number];

/** Sections reservees aux roles declares dans API_STAFF_ROLE_IDS. */
const STAFF_ONLY: readonly Section[] = ["recruitment", "orders", "monitoring", "storage", "webhooks"];

/** Sections ouvertes a tout membre du serveur. */
const MEMBER_SECTIONS: readonly Section[] = ["overview", "catalog", "absences"];

let warnedAboutOpenPolicy = false;

/**
 * Avertit une seule fois si aucun role n'est declare : dans cet etat tout membre du serveur
 * voit le coffre et les factures. C'est un choix defendable au demarrage, mais il doit etre
 * conscient — d'ou la trace au demarrage plutot qu'un silence.
 */
function warnOnceIfOpen(): void {
  if (warnedAboutOpenPolicy || env.API_STAFF_ROLE_IDS.length > 0) return;
  warnedAboutOpenPolicy = true;
  logger.warn(
    "API_STAFF_ROLE_IDS est vide : tout membre du serveur peut lire le coffre, les factures et les candidatures. " +
      "Renseignez des ids de role pour restreindre ces sections.",
  );
}

export function canRead(viewer: Viewer, section: Section): boolean {
  warnOnceIfOpen();
  if (MEMBER_SECTIONS.includes(section)) return true;
  if (STAFF_ONLY.includes(section)) return viewer.isStaff;
  return false;
}

/** Sections que ce visiteur peut consulter — sert au site pour n'afficher que l'accessible. */
export function grantedSections(viewer: Viewer): Section[] {
  return SECTIONS.filter((section) => canRead(viewer, section));
}
